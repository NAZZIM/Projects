### Steps to reproduce
1.
2.
3.

### Expected behavior
Tell us what should happen

### Actual behavior
Tell us what happens instead

### Version of SharpZipLib

### Obtained from (place an x between the brackets for all that apply)
- [ ] Compiled from source
 - branch: _______
 - commit: _______
- [ ] Downloaded DLL from GitHub
- [ ] Downloaded DLL from SourceForge
- [ ] Downloaded DLL from _______
- [ ] DLL included as part of
- Package installed using:
 - [ ] NuGet
 - [ ] MyGet
 - [ ] Chocolatey
