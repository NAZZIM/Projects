using System;
using System.Reflection;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("ICSharpCode.SharpZipLib.Tests")]
[assembly: AssemblyDescription("NUnit test suite for SharpZipLib")]
[assembly: AssemblyCulture("")]

[assembly: CLSCompliant(true)]
