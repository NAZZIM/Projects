Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("CreateZipFile")>
<Assembly: AssemblyDescription("SharpZipLib Sample Project")>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("00351BD7-45C3-443F-9D63-211DB7AB703B")>
