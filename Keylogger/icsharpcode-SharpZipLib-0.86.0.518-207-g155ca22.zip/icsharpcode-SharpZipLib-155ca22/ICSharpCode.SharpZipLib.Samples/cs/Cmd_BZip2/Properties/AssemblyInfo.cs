using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Cmd_BZip2")]
[assembly: AssemblyDescription("bzip2 based file compression")]
[assembly: AssemblyCulture("")]
